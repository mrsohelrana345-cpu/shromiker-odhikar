const form = document.getElementById("form");
const success = document.getElementById("success");

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const fd = new FormData(form);
  const r = await fetch("/api/complaints", { method: "POST", body: fd });
  const data = await r.json();

  if (!r.ok) return alert(data.error || "অভিযোগ জমা হয়নি।");

  success.style.display = "block";
  success.innerHTML = `
    <b>অভিযোগ সফলভাবে জমা হয়েছে।</b><br>
    আপনার Complaint ID: <strong>${data.complaint_id}</strong><br>
    এই নম্বরটি সংরক্ষণ করুন।
  `;
  form.reset();
});

document.getElementById("trackForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const id = document.getElementById("trackId").value.trim();
  const result = document.getElementById("result");
  const r = await fetch("/api/complaints/" + encodeURIComponent(id));
  const data = await r.json();

  if (!r.ok) {
    result.innerHTML = `<div class="error">${data.error}</div>`;
    return;
  }

  result.innerHTML = `
    <div class="track">
      <b>${data.complaint_id}</b>
      <p>কারখানা: ${data.factory}</p>
      <p>অভিযোগ: ${data.complaint_type}</p>
      <p>স্ট্যাটাস: <strong>${data.status}</strong></p>
      <small>শেষ আপডেট: ${new Date(data.updated_at).toLocaleString("bn-BD")}</small>
    </div>`;
});