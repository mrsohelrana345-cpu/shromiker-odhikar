const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const multer = require("multer");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "CHANGE_THIS_SECRET_BEFORE_DEPLOYMENT";

const dataDir = path.join(__dirname, "data");
const uploadDir = path.join(__dirname, "uploads");
fs.mkdirSync(dataDir, { recursive: true });
fs.mkdirSync(uploadDir, { recursive: true });

const db = new Database(path.join(dataDir, "complaints.db"));
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS complaints (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  complaint_id TEXT UNIQUE NOT NULL,
  name TEXT,
  phone TEXT NOT NULL,
  factory TEXT NOT NULL,
  address TEXT,
  complaint_type TEXT NOT NULL,
  details TEXT NOT NULL,
  anonymous INTEGER DEFAULT 0,
  evidence_file TEXT,
  status TEXT DEFAULT 'Received',
  admin_note TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS admins (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL
);
`);

const adminCount = db.prepare("SELECT COUNT(*) AS n FROM admins").get().n;
if (adminCount === 0) {
  const username = process.env.ADMIN_USER || "admin";
  const password = process.env.ADMIN_PASSWORD || "ChangeMe123!";
  const hash = bcrypt.hashSync(password, 12);
  db.prepare("INSERT INTO admins (username, password_hash) VALUES (?, ?)")
    .run(username, hash);
  console.log(`Initial admin created: ${username}. Change the password before public deployment.`);
}

app.use(helmet({
  crossOriginResourcePolicy: { policy: "cross-origin" }
}));
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true, limit: "1mb" }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 200 }));

const storage = multer.diskStorage({
  destination: uploadDir,
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, crypto.randomUUID() + ext);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = [".pdf", ".jpg", ".jpeg", ".png"];
    cb(null, allowed.includes(path.extname(file.originalname).toLowerCase()));
  }
});

function makeComplaintId() {
  return "SR-" + new Date().getFullYear() + "-" +
    crypto.randomBytes(3).toString("hex").toUpperCase();
}

function auth(req, res, next) {
  const token = (req.headers.authorization || "").replace("Bearer ", "");
  try {
    req.admin = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: "Unauthorized" });
  }
}

app.use(express.static(path.join(__dirname, "public")));

app.post("/api/complaints", upload.single("evidence"), (req, res) => {
  const {
    name = "", phone, factory, address = "",
    complaint_type, details, anonymous = "0"
  } = req.body;

  if (!phone || !factory || !complaint_type || !details) {
    return res.status(400).json({ error: "Required fields are missing." });
  }

  const complaintId = makeComplaintId();
  const now = new Date().toISOString();

  db.prepare(`
    INSERT INTO complaints
    (complaint_id,name,phone,factory,address,complaint_type,details,anonymous,evidence_file,status,created_at,updated_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
  `).run(
    complaintId, name, phone, factory, address, complaint_type,
    details, anonymous === "1" ? 1 : 0,
    req.file ? req.file.filename : null,
    "Received", now, now
  );

  res.json({
    success: true,
    complaint_id: complaintId,
    status: "Received"
  });
});

app.get("/api/complaints/:id", (req, res) => {
  const c = db.prepare(`
    SELECT complaint_id, complaint_type, factory, status, created_at, updated_at
    FROM complaints WHERE complaint_id = ?
  `).get(req.params.id.trim().toUpperCase());

  if (!c) return res.status(404).json({ error: "Complaint not found." });
  res.json(c);
});

app.post("/api/admin/login", (req, res) => {
  const { username, password } = req.body;
  const admin = db.prepare("SELECT * FROM admins WHERE username = ?").get(username || "");
  if (!admin || !bcrypt.compareSync(password || "", admin.password_hash)) {
    return res.status(401).json({ error: "Invalid login." });
  }
  const token = jwt.sign({ id: admin.id, username: admin.username }, JWT_SECRET, { expiresIn: "8h" });
  res.json({ token });
});

app.get("/api/admin/complaints", auth, (req, res) => {
  const rows = db.prepare(`
    SELECT id, complaint_id, name, phone, factory, address, complaint_type,
           details, anonymous, evidence_file, status, admin_note, created_at, updated_at
    FROM complaints ORDER BY id DESC
  `).all();
  res.json(rows);
});

app.patch("/api/admin/complaints/:id", auth, (req, res) => {
  const { status, admin_note = "" } = req.body;
  const allowed = ["Received", "Reviewing", "Under Investigation", "Resolved", "Closed"];
  if (!allowed.includes(status)) return res.status(400).json({ error: "Invalid status." });

  const now = new Date().toISOString();
  const result = db.prepare(`
    UPDATE complaints SET status = ?, admin_note = ?, updated_at = ?
    WHERE complaint_id = ?
  `).run(status, admin_note, now, req.params.id);

  if (!result.changes) return res.status(404).json({ error: "Complaint not found." });
  res.json({ success: true });
});

app.get("/api/admin/stats", auth, (req, res) => {
  const total = db.prepare("SELECT COUNT(*) AS n FROM complaints").get().n;
  const received = db.prepare("SELECT COUNT(*) AS n FROM complaints WHERE status='Received'").get().n;
  const investigating = db.prepare("SELECT COUNT(*) AS n FROM complaints WHERE status='Under Investigation'").get().n;
  const resolved = db.prepare("SELECT COUNT(*) AS n FROM complaints WHERE status='Resolved'").get().n;
  res.json({ total, received, investigating, resolved });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
